import com.github.javafaker.Faker;
        import org.openqa.selenium.By;
        import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
        import org.openqa.selenium.firefox.FirefoxDriver;
        import org.openqa.selenium.firefox.FirefoxOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import sun.awt.windows.WEmbeddedFrame;

public class Main {
    static public FirefoxDriver driver;
    static public Faker faker;

    static public void main(String[] args){
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Camila Gavilan\\Downloads\\geckodriver-v0.26.0-win64\\geckodriver.exe");

        //Headless
        /*FirefoxBinary firefoxBinary = new FirefoxBinary();
        FirefoxOptions options = new FirefoxOptions();
        options.setBinary(firefoxBinary);
        options.setHeadless(true);
        driver = new FirefoxDriver(options);*/

        //Normal
        driver = new FirefoxDriver();

        faker = new Faker();

        //System.out.println("\nTest mostrar productos " + (TestMostrarProductos() ? "passed!":"failed!"));
        //System.out.println("\nTest mostrar destacados " + (TestMostrarDestacados() ? "passed!":"failed!"));

        /*
        for (int i = 0; i < 3; i++) {
            System.out.println("\nTest agregar producto " + (TestAgregarProductoCarro() ? "passed!":"failed!"));
        }*/

        //System.out.println("\nTest crear producto " + (TestCrearProducto() ? "passed!":"failed!"));
        //System.out.println("\nTest eliminar producto " + (TestEliminarProducto() ? "passed!":"failed!"));
        //System.out.println("\nTest modificar producto " + (TestModificarProducto() ? "passed!":"failed!"));
        //System.out.println("\nTest agregar/quitar producto destacado " + (TestAgregarQuitarProductoDestacado() ? "passed!":"failed!"));
        //System.out.println("\nTest cambiar disponibilidad producto " + (TestCambiarDisponibilidadProducto() ? "passed!":"failed!"));

        /*
        //Testear estos dos test juntos.
        System.out.println("\nTest agregar producto carro " + (TestAgregarProductoCarro() ? "passed!":"failed!"));
        System.out.println("\nTest quitar producto carro " + (TestQuitarProductoCarro() ? "passed!":"failed!"));
        */
        //System.out.println("\nTest crear cuenta cliente " + (TestCrearCliente() ? "passed!":"failed!"));
        System.out.println("\nTest barra navegacion " + (TestBarraNavegacion() ? "passed!":"failed!"));

    }

    static public boolean TestMostrarProductos(){
        driver.get("http://localhost:3000/");

        List<WebElement> productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card' and @style='width: 18rem;']");

        if(productos.size()>0){
            String tituloPrimerProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div[1]/div[1]/div[1]")).getText();
            if(!tituloPrimerProducto.isEmpty() && tituloPrimerProducto != null) {
                //System.out.printf("Titulo del primer producto: "+tituloPrimerProducto);
                return true;
            }
        }
        return false;
    }

    static public boolean TestMostrarDestacados(){
        driver.get("http://localhost:3000/");
        List<WebElement> destacadoCarrusel = driver.findElements(By.xpath("/html/body/div[1]/div[2]/div/div/div/div[@class='active carousel-item']"));
        //System.out.println(destacadoCarrusel.size());

        WebElement carruselActivo =  driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div[@class='active carousel-item']/div[@class='carousel-caption']"));
        String tituloProductoDestacado = carruselActivo.findElement(By.tagName("h2")).getText();
        //System.out.println("Titulo del primer producto destacado: "+tituloProductoDestacado);

        if(destacadoCarrusel.size()>0){
            if(!tituloProductoDestacado.isEmpty() && tituloProductoDestacado != null){
                return true;
            }
        }
        return false;
    }

    static public boolean TestCrearProducto(){
        driver.get("http://localhost:3000/");
        List<WebElement> productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']");
        //System.out.println("Cantidad de productos= "+productos.size());

        driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();

        String name = faker.food().sushi();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[1]/input[@id='nombre']")).sendKeys(name);

        String precio = faker.number().digits(5);
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[2]/div/input[@id='precio']")).sendKeys(precio);

        String descripcion = faker.lorem().paragraph();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[3]/textarea[@id='descripcion']")).sendKeys(descripcion);

        String categoria = "Comestible";
        Select categoriaElement = new Select(driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[4]/select[@id='categoria' and @class='form-control']")));
        categoriaElement.selectByVisibleText(categoria);

        String imagen = "cami.jpg";
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[5]/div/input[@id='imagen']")).sendKeys("C:\\Users\\Camila Gavilan\\Pictures\\"+imagen);

        WebElement destacado = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[6]/input[@id='destacado']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(destacado).click().build().perform();

        driver.findElement(By.xpath("//button[@type='submit' and contains(., 'Crear producto')]")).click();

        productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']");
        //System.out.println("Cantidad de productos= "+productos.size());

        if(productos.size()>0){
            String tituloProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productos.size()+"]/div[1]/div[1]")).getText();
            String precioProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productos.size()+"]/div[1]/div[2]")).getText();
            String imagenProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productos.size()+"]/img")).getAttribute("src");
            if(name.equals(tituloProducto)){
                System.out.println("\nnombre correcto");
                if(precioProducto.contains(precio)){
                    System.out.println("\nprecio correcto");
                    if(imagenProducto.contains(imagen)){
                        System.out.println("\nimagen correcta");
                        return true;
                    }
                    else{
                        System.out.println("\nimagen incorrecta: "+imagenProducto);
                        return false;
                    }
                }
                else{
                    System.out.println("\nprecio incorrecto: "+precioProducto);
                    return false;
                }
            }
            else{
                System.out.println("\nnombre incorrecto: "+tituloProducto);
                return false;
            }
        }
        return false;
    }

    static public boolean TestEliminarProducto(){
        driver.get("http://localhost:3000/");
        List<WebElement> productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']");
        int productoEliminar = faker.number().numberBetween(1,productos.size());
        System.out.println(productoEliminar);

        String nombreProductoBorrar = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEliminar+"]/div[1]/div[1]")).getText();
        System.out.println(nombreProductoBorrar);

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEliminar+"]/div[2]/div/button[2]")).click();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/div[3]/button[1]")).click();

        productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']");
        /*
        String styleEliminado = "opacity: 0.4; width: 18rem;";

        if(styleEliminado.equals(driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEliminar+"]")).getAttribute("style"))){
            System.out.println(driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEliminar+"]")).getAttribute("style"));
            return true;
        }
        return false;
        */
        for (int i = 1; i < productos.size(); i++) {
            String nombreEncontrado = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+i+"]/div[1]/div[1]")).getText();
            if(nombreProductoBorrar.equals(nombreEncontrado)){
                System.out.println(nombreEncontrado);
                return false;
            }
        }
        return true;
    }

    static public boolean TestModificarProducto() {
        driver.get("http://localhost:3000/");
        List<WebElement> productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']");
        int productoEditar = faker.number().numberBetween(1,productos.size());

        String nombreProductoEditar = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[1]/div[1]")).getText();
        System.out.println(nombreProductoEditar);

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[2]/div/button[1]")).click();

        String name = faker.food().sushi();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[1]/input[@id='nombre']")).clear();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[1]/input[@id='nombre']")).sendKeys(name);

        String precio = faker.number().digits(5);
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[2]/div/input[@id='precio']")).clear();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[2]/div/input[@id='precio']")).sendKeys(precio);

        String descripcion = faker.lorem().paragraph();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[3]/textarea[@id='descripcion']")).clear();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[3]/textarea[@id='descripcion']")).sendKeys(descripcion);

        String categoria = "Comestible";
        Select categoriaElement = new Select(driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[4]/select[@id='categoria' and @class='form-control']")));
        categoriaElement.selectByVisibleText(categoria);

        String imagen = "cami.jpg";
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[5]/div/input[@id='imagen']")).sendKeys("C:\\Users\\Camila Gavilan\\Pictures\\"+imagen);

        WebElement disponible = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[6]/input[@id='disponible']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(disponible).click().build().perform();

        WebElement destacado = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[7]/input[@id='destacado']"));
        actions = new Actions(driver);
        actions.moveToElement(destacado).click().build().perform();

        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[2]/button[1]")).click();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[2]/button[2]")).click();

        String tituloProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[1]/div[1]")).getText();
        String precioProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[1]/div[2]")).getText();
        String imagenProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/img")).getAttribute("src");

        if(productos.size()>0) {
            if (name.equals(tituloProducto) && precioProducto.contains(precio) && imagenProducto.contains(imagen)) {
                return true;
            }
        }
        System.out.println(tituloProducto+" / "+name);
        System.out.println(precioProducto+" / "+precio);
        System.out.println(imagenProducto+" / "+imagen);
        return false;
    }

    static public boolean TestAgregarQuitarProductoDestacado() {
        driver.get("http://localhost:3000/");
        List<WebElement> productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']");
        int productoEditar = faker.number().numberBetween(1,productos.size());

        String nombreProductoEditar = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[1]/div[1]")).getText();
        System.out.println(nombreProductoEditar);

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[2]/div/button[1]")).click();

        WebElement destacado = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[7]/input[@id='destacado']"));
        boolean estadoDestacado = destacado.isSelected();

        Actions actions = new Actions(driver);
        actions.moveToElement(destacado).click().build().perform();

        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[2]/button[1]")).click();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[2]/button[2]")).click();

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[2]/div/button[1]")).click();
        destacado = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[7]/input[@id='destacado']"));
        boolean nuevoEstadoDestacado = destacado.isSelected();

        if(estadoDestacado != nuevoEstadoDestacado){
            return true;
        }
        return false;
    }

    static public boolean TestCambiarDisponibilidadProducto() {
        driver.get("http://localhost:3000/");
        List<WebElement> productos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']");
        int productoEditar = faker.number().numberBetween(1,productos.size());

        String nombreProductoEditar = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[1]/div[1]")).getText();
        System.out.println(nombreProductoEditar);

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[2]/div/button[1]")).click();

        WebElement disponible = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[6]/input[@id='disponible']"));
        boolean estadoDisponible= disponible.isSelected();

        Actions actions = new Actions(driver);
        actions.moveToElement(disponible).click().build().perform();

        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[2]/button[1]")).click();
        driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[2]/button[2]")).click();

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]/div[2]/div/button[1]")).click();
        disponible = driver.findElement(By.xpath("/html/body/div[4]/div/div/form/div[1]/div[6]/input[@id='disponible']"));
        boolean nuevoEstadoDisponible = disponible.isSelected();

        if(estadoDisponible != nuevoEstadoDisponible){
            String styleEliminado = "opacity: 0.4; width: 18rem;";
            if(styleEliminado.equals(driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]")).getAttribute("style"))){
                return true;
            }
        }
        //System.out.println(driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoEditar+"]")).getAttribute("style"));
        return false;
    }

    static public int AgregarProductoCarro(int cantidad) {
        int cantidadProductos = driver.findElementsByXPath("/html/body/div[2]/div[2]/div[2]/div/div[@class='m-4 card']").size();
        List <Integer> productosDisponibles = new ArrayList<Integer>();

        for (int i = 1; i < cantidadProductos; i++) {
            WebElement producto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+i+"]"));

            if(!(producto.getAttribute("style").contains("opacity: 0.4"))){
                productosDisponibles.add(i);
            }
        }
        int productoAgregar = productosDisponibles.get(faker.number().numberBetween(1,productosDisponibles.size()));
        for (int i = 0; i < cantidad; i++) {
            driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+productoAgregar+"]/div[2]/button")).click();
        }
        return productoAgregar;
    }

    static public boolean TestAgregarProductoCarro() {
        driver.get("http://localhost:3000/");

        int cantidadProducto1 = faker.number().numberBetween(1,10);
        int cantidadProducto2 = faker.number().numberBetween(1,10);
        int cantidadProducto3 = faker.number().numberBetween(1,10);

        int producto1 = AgregarProductoCarro(cantidadProducto1);
        int producto2 = AgregarProductoCarro(cantidadProducto2);
        int producto3 = AgregarProductoCarro(cantidadProducto3);

        int totalPrecioProducto1 = cantidadProducto1*(Integer.parseInt((driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+producto1+"]/div[1]/div[2]")).getText()).replaceAll("\\D+","")));
        int totalPrecioProducto2 = cantidadProducto2*(Integer.parseInt((driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+producto2+"]/div[1]/div[2]")).getText()).replaceAll("\\D+","")));
        int totalPrecioProducto3 = cantidadProducto3*(Integer.parseInt((driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+producto3+"]/div[1]/div[2]")).getText()).replaceAll("\\D+","")));

        int totalPrecioProductos = totalPrecioProducto1+totalPrecioProducto2+totalPrecioProducto3;

        driver.findElement(By.xpath("/html/body/nav/button[2]")).click();

        boolean checkProducto1 = verificarProductoCarro(producto1,cantidadProducto1);
        boolean checkProducto2 = verificarProductoCarro(producto2,cantidadProducto2);
        boolean checkProducto3 = verificarProductoCarro(producto3,cantidadProducto3);

        if(checkProducto1 && checkProducto2 && checkProducto3){
            if(totalPrecioProductos == Integer.parseInt((driver.findElement(By.xpath("/html/body/div[3]/div[2]/h3[2]")).getText()).replaceAll("\\D+",""))){
                return true;
            }
        }
        return false;
    }

    static public boolean verificarProductoCarro(int producto, int cantidad) {
        String nombreProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+producto+"]/div[1]/div[1]")).getText();
        String precioProducto = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div/div["+producto+"]/div[1]/div[2]")).getText();
        int precio = Integer.parseInt(precioProducto.replaceAll("\\D+",""));
        //System.out.println(precio);

        int totalPrecio = precio*cantidad;
        //System.out.println(totalPrecio);

        int cantidadProductosCarro = driver.findElements(By.xpath("/html/body/div[3]/div[2]/div/table/tbody/tr")).size();
        //System.out.println(cantidadProductosCarro);

        if(cantidadProductosCarro>0){
            for (int i = 1; i < cantidadProductosCarro+1; i++) {
                String nombreProductoCarro = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/table/tbody/tr["+i+"]/td[1]")).getText();
                int cantidadProductoCarro =  Integer.parseInt(driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/table/tbody/tr["+i+"]/td[2]")).getText());
                String totalProductoCarro = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/table/tbody/tr["+i+"]/td[3]")).getText();
                int totalPrecioProductoCarro = Integer.parseInt(totalProductoCarro.replaceAll("\\D+",""));

                if((nombreProductoCarro.equals(nombreProducto)) && (cantidadProductoCarro == cantidad) && (totalPrecio == totalPrecioProductoCarro)){
                    return true;
                }
            }
        }
        return false;
    }

    static public boolean TestQuitarProductoCarro() {
        //driver.get("http://localhost:3000/");
        int cantidadProductosCarro = driver.findElements(By.xpath("/html/body/div[3]/div[2]/div/table/tbody/tr")).size();

        if(cantidadProductosCarro>0){
            int productoEliminarCarro = faker.number().numberBetween(1,cantidadProductosCarro);
            String idProducto = driver.findElementByXPath("/html/body/div[3]/div[2]/div/table/tbody/tr["+productoEliminarCarro+"]/td[4]/button").getAttribute("idproducto");
            driver.findElementByXPath("/html/body/div[3]/div[2]/div/table/tbody/tr["+productoEliminarCarro+"]/td[4]/button").click();
            int cantidadProductosPostDelete = driver.findElements(By.xpath("/html/body/div[3]/div[2]/div/table/tbody/tr")).size();

            if((cantidadProductosCarro-1) == cantidadProductosPostDelete) {
                for (int i = 1; i <= cantidadProductosPostDelete; i++) {
                    if ((driver.findElementByXPath("/html/body/div[3]/div[2]/div/table/tbody/tr[" + i + "]/td[4]/button").getAttribute("idproducto")) == idProducto) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    static public boolean TestCrearCliente() {
        driver.get("http://localhost:3000/");
        driver.findElementByXPath("/html/body/nav/div[1]/a[4]").click();

        String nombre = faker.name().firstName();
        driver.findElementByXPath("/html/body/div/div[2]/form/div[1]/div[1]/div/input[@id='nombre']").sendKeys(nombre);

        String apellido = faker.name().lastName();
        driver.findElementByXPath("/html/body/div/div[2]/form/div[1]/div[2]/div/input[@id='apellido']").sendKeys(apellido);

        String email = faker.internet().emailAddress();
        driver.findElementByXPath("/html/body/div/div[2]/form/div[2]/div[1]/div/input[@id='email']").sendKeys(email);

        String telefono = faker.phoneNumber().cellPhone();
        driver.findElementByXPath("/html/body/div/div[2]/form/div[2]/div[2]/div/input[@id='telefono']").sendKeys(telefono);

        String direccion = faker.address().streetAddress();
        driver.findElementByXPath("/html/body/div/div[2]/form/div[3]/textarea[@id='direccion']").sendKeys(direccion);

        String contraseña = faker.overwatch().hero();
        driver.findElementByXPath("/html/body/div/div[2]/form/div[4]/input[@id='contraseña']").sendKeys(contraseña);
        driver.findElementByXPath("/html/body/div/div[2]/form/div[5]/input[@id='contraseñaValidacion']").sendKeys(contraseña);

        driver.findElementByXPath("/html/body/div/div[2]/form/button").click();

        System.out.println(contraseña);
        return false;

    }

    static public boolean TestBarraNavegacion() {
        driver.get("http://localhost:3000/");

        int barrasIzquierda =   driver.findElementsByXPath("/html/body/nav/div[1]/a").size();
        System.out.println(barrasIzquierda);

        for (int i = 1; i <= barrasIzquierda; i++) {
            driver.findElementByXPath("/html/body/nav/div[1]/a["+i+"]").click();
            if(!(driver.getTitle().contains(driver.findElementByXPath("/html/body/nav/div[1]/a["+i+"]").getText()))){
                System.out.println(driver.findElementByXPath("/html/body/nav/div[1]/a[1]").getText());
                System.out.println(driver.getTitle());
                return false;
            }
        }
        driver.findElementByXPath("/html/body/nav/div[2]/a").click();
        if(!(driver.getTitle().contains(driver.findElementByXPath("/html/body/nav/div[2]/a").getText()))){
            return false;
        }
        return true;
    }
}
